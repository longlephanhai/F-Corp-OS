export class CreateUserSprintDto {}
