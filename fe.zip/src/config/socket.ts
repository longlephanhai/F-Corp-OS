import { io } from 'socket.io-client';

const SOCKET_URL = 'http://localhost:8080';

export const socket = io(SOCKET_URL, {
    transports: ['websocket'],
    autoConnect: true,
    auth: (cb) => {
        cb({ token: localStorage.getItem('access_token') });
    },
});


export const reconnectSocketWithAuth = () => {
    socket.disconnect();
    socket.connect();
};

socket.on('connect', () => {
    console.log(`🟢 [Socket.io] Đã nối cáp thành công! ID: ${socket.id}`);
});

socket.on('disconnect', () => {
    console.log('🔴 [Socket.io] Mất kết nối tới Server!');
});