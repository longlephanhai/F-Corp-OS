import { Layout, Menu } from 'antd';
import { FaKey, FaShieldAlt, FaUser } from 'react-icons/fa';
import { useLocation, useNavigate } from 'react-router';
const { Sider } = Layout;
import { DashboardOutlined } from '@ant-design/icons';

interface IProps {
    collapsed: boolean;
    pathName: string;
}

const SiderLayout = (props: IProps) => {
    const navigate = useNavigate();
    const location = useLocation();
    const { collapsed } = props;

    const selectedKey =
        location.pathname.replace(/^\/admin\/?/, '') || 'dashboard';

    return (
        <Sider trigger={null} collapsible collapsed={collapsed}>
            <div
                style={{
                    height: 64,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderBottom: '1px solid rgba(255,255,255,0.1)',
                }}
            >
                <h2
                    style={{
                        color: '#fff',
                        margin: 0,
                        fontSize: collapsed ? 14 : 16,
                        fontWeight: 700,
                        letterSpacing: 0.5,
                        transition: 'font-size 0.2s',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                    }}
                >
                    {collapsed ? 'FC' : 'F-Corp OS'}
                </h2>
            </div>

            <Menu
                theme="dark"
                mode="inline"
                selectedKeys={[selectedKey]}
                style={{ borderRight: 0, marginTop: 8 }}
                items={[
                    {
                        key: 'dashboard',
                        icon: <DashboardOutlined />,
                        label: 'Dashboard',
                        onClick: () => navigate('/admin'),
                    },
                    {
                        key: 'users',
                        icon: <FaUser />,
                        label: 'Users',
                        onClick: () => navigate('users')
                    },
                    {
                        key: 'roles',
                        icon: <FaShieldAlt />,
                        label: 'Roles',
                        onClick: () => navigate('roles')
                    },
                    {
                        key: 'permissions',
                        icon: <FaKey />,
                        label: 'Permissions',
                        onClick: () => navigate('permissions')
                    }
                ]}
            />
        </Sider>
    );
};

export default SiderLayout;